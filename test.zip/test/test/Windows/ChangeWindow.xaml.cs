﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using test.Entities;

namespace test.Windows
{
    /// <summary>
    /// Логика взаимодействия для ChangeWindow.xaml
    /// </summary>
    public partial class ChangeWindow : Window
    {
        Entities.testEntities db = Helper.GetContext();
        Books book;
        public ChangeWindow(int idSelected)
        {
            InitializeComponent();
            book = db.Books.Where(a => a.idBook == idSelected).FirstOrDefault();
            AuthorBox.SelectedIndex = book.Authors.idAuthor-1;
            TitleBox.Text = book.Title;
            ThemeBox.SelectedIndex = book.Themes.idTheme-1;
             PublicatinYearBox.Text = book.PublicationYear.ToString();

        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            MainWindow mainWindow = new MainWindow();
            mainWindow.ShowDialog();
        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                book.idAuthor = int.Parse(AuthorBox.Text.Trim());
                book.Title = TitleBox.Text.Trim();
                book.idTheme = ThemeBox.SelectedIndex;
                book.PublicationYear = short.Parse(PublicatinYearBox.Text.Trim());
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                this.Close();
                MessageBox.Show("Успешно сохранено!");
                MainWindow mainWindow = new MainWindow();
                mainWindow.ShowDialog();
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }
    }
}
