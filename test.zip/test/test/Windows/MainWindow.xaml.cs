﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using test.Entities;
using test.Windows;

namespace test 
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Entities.testEntities db = Helper.GetContext();
        public MainWindow()
        {
            InitializeComponent();
          //mainGrid.ItemsSource = db.Books.ToList();
           mainGrid.ItemsSource = db.Books.Select(b => new { b.idBook, AuthorName = b.Authors.AuthorName, b.Title, ThemeName = b.Themes.ThemeName, b.PublicationYear }).ToList();
        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Windows.AddWindow addWindow = new Windows.AddWindow();
            addWindow.ShowDialog();
        }

        private void changeBtn_Click(object sender, RoutedEventArgs e)
        {
            int books = mainGrid.SelectedIndex+1;
            if (books != null)
            {
                this.Hide();
                ChangeWindow changeWindow = new ChangeWindow(books);
                changeWindow.ShowDialog();
               mainGrid.ItemsSource = db.Books.Select(b => new { b.idBook, AuthorName = b.Authors.AuthorName, b.Title, ThemeName = b.Themes.ThemeName, b.PublicationYear }).ToList();
            }

        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Удаление", "Вы хотите удалить строку?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                int books = mainGrid.SelectedIndex + 1;
                Books book = db.Books.Find(books);
                if (book != null)
                {
                    db.Books.Remove(book);
                    db.SaveChanges();
                    mainGrid.ItemsSource = db.Books.Select(b => new { b.idBook, AuthorName = b.Authors.AuthorName, b.Title, ThemeName = b.Themes.ThemeName, b.PublicationYear }).ToList();
                    MessageBox.Show("Строка удалена");
                }
            }
        }

        private void mainGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
