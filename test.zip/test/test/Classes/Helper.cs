﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Helper
    {
        private static Entities.testEntities TestEntities;

        public static Entities.testEntities GetContext()
        {
            if (TestEntities == null)
                TestEntities = new Entities.testEntities();
            return TestEntities;
        }
    }
}
